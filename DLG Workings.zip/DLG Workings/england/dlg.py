import pandas as pd
import os

# Convert csv to parquet
def convert_csv_parquet(csv_file_name):
    # read csvf file
    df = pd.read_csv("csv/" + csv_file_name)
    # write csv to parquet with dataframe and default raq group of pyarrow
    df.to_parquet('parquet/' + csv_file_name + ".parquet", engine='pyarrow', index=False)


# Query parquet file
def query_parquet(parquet_file_name):
    # read parqet with pyarrow engine
    data = pd.read_parquet('parquet/' + parquet_file_name, engine='pyarrow')

    # query with max temperature
    temperature = str(data.max(axis=0)[7])
    # get one row with max temperature
    row = data.query('ScreenTemperature==' + temperature)
    # get region
    region = row['Region'].values[0]
    # date of max temperature
    day = row['ObservationDate'].values[0]
    print('     ' + parquet_file_name + '\'s result:')
    print("         hottest day: " + day)
    print("         temperature : " + temperature)
    print("         region : " + region)


# main endpoint for starting to work
def start():
    # BEGIN: start to convert CSV to parquet file
    print("Read all csv files")
    csv_files = [f for f in os.listdir('csv/')]
    for csv_file in csv_files:
        # Convert csv to parquet file
        convert_csv_parquet(csv_file)
    # END:

    # BEGIN: start to query parquet file
    print("Query:")
    parquet_files = [f for f in os.listdir('parquet/')]
    for parquet_file in parquet_files:
        # Query parquet file
        query_parquet(parquet_file)
    # END:

start()